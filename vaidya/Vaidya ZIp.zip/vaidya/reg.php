<?php
$host="localhost";
$username="root";
$password="";
$database_name="vaidya";

$conn = mysqli_connect($host,$username,$password,$database_name);
//now check the connection
if(!$conn)
{
die("Connection Failed:" . mysqli_connect_error());

}

if(isset($_POST['Register']))
{
    $Username = $_POST['Username'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    $sql_query = "INSERT INTO user_info (Username,first_name,last_name,email,password)
VALUES ('$Username','$first_name','$last_name','$email','$password')";


    if($result = mysqli_query($conn ,$sql_query))
       header("Location: log.php");

// if (mysqli_query($conn, $sql_query) )
// {
// echo '<p>New Details Entry inserted successfully You can now <a href= "/vaidya/log.php" >login</a> to your account</p>';
//     }
// else
// {
// 		echo "Error: " . $sql . "" . mysqli_error($conn);
// }
mysqli_close($conn);
}

?>
